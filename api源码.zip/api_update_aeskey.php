<?php

require 'config.php';

$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$appid=$_REQUEST['appid'];
$aeskey=$_REQUEST['aeskey'];
if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''||$appid==''||$aeskey==''){die('参数不完整');}
//if(!strlen($aeskey)>15||!strlen($aeskey)<17){die('aes密匙长度必须是16位');}

$sql=mysqli_query($link,"select * from user where user='$zh' and password='$mm'");
if(!mysqli_num_rows($sql)>0){die('账号或密码错误');}
$sql=mysqli_query($link,"select * from api where user='$zh' and id='$appid'");
if(mysqli_num_rows($sql)>0){}else{die('应用api不存在');}
$sql=mysqli_query($link,"update api set aeskey='$aeskey' where user='$zh' and id='$appid'");
if($sql){die('修改成功');}else{die('修改失败');}


?>