<?php

require '../config.php';
$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$appid=$_REQUEST['appid'];

if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''||$appid==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from user where user='$zh' and password='$mm'");
if(!mysqli_num_rows($sql)>0){die('账号或密码错误');}

$sql=mysqli_query($link,"select * from api where id='$appid' and user='$zh'");
$row=mysqli_fetch_assoc($sql);
echo $row['aeskey'];


?>