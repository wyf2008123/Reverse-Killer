<?php

require 'config.php';

$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];

if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
if(!mysqli_num_rows($sql)>0){die('账号不存在');}else{$array=mysqli_fetch_assoc($sql);}

if($array['ban']=='true'){die('您的账号已被封禁');}
if($mm==$array['password']){die('登录成功');}else{die('账号或密码错误');}


?>