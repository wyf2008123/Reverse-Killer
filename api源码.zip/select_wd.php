<?php

require 'config.php';
if(!$link){die('数据库链接失败');}
$sql=mysqli_query($link,"select * from wd order by id desc");
for ($i = 0; $i < mysqli_num_rows($sql); $i++) {
    $row=mysqli_fetch_assoc($sql);
    echo '[title]'.$row['title'].'[title]'.'[content]'.$row['content'].'[content]'.'[link]'.$row['link'].'[link]'.'<br>';
}

?>