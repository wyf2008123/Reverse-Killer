<html> 
 <head> 
  <meta charset="utf-8"> 
  <title>简验证</title> 
  <meta name="description" content="简验证APP，iapp后台验证管理系统，稳定,高效,全能型后台管理系统，只为用户更好的体验！"> 
  <meta name="keywords" content="我们拥有id系统,id控制台,创建api,对接示例...更多功能正在努力开发中"> 
  <meta http-equiv="x-ua-compatible" content="ie=edge"> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
  <link rel="stylesheet" href="css/base.css"> 
  <link rel="shortcut icon" href="res/favicon.ico"> <!-- Global site tag (gtag.js) - Google Analytics --> 
  <script async src="gtag/js?id=UA-140886138-3"></script> 
  <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-140886138-3');
    </script> 
 </head> 
 <body> 
  <div id="container"> 
   <div class="wrapper" style="background-color: rgb(248, 250, 255);"> 
    <div class="wrapper"> 
     <header class="page-header" id="page-header"> 
      <div class="nav-container"> 
       <div class="nav-left"> 
        <div class="logo"> <a href="#/"><!--  <img class="logo-img" src="./res/zm.png">  <span></span> --></a>
        </div><i class="icon icon-menu nav-icon"></i> 
       </div> 
       <div class="nav-right" style="height: 0px;"> 
        <ul class="navbar" style="margin: 0;"> 
         <li> <a href="" target="__blank">关于我们</a> </li> 
        </ul> 
       </div> 
      </div> 
     </header> 
     <div class="bg-container"> 
      <div class="bg-top-border"></div> 
      <div class="bg-top-shadow"></div> 
      <div class="bg-bottom-border"></div> 
      <div class="bg-bottom-shadow"></div> 
      <div class="info-container"> 
       <div class="img-container"> 
        <div class="span6" style="width: 660px;"> 
         <svg class="ngrok-demo spread-windows" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 0 680 540"> <defs> 
           <filter id="ngrok-demo-a" width="108.3%" height="115.6%" x="-3.3%" y="-6.2%" filterunits="objectBoundingBox"> 
            <feoffset dx="5" dy="5" in="SourceAlpha" result="shadowOffsetOuter1"> 
            </feoffset> 
            <fegaussianblur in="shadowOffsetOuter1" result="shadowBlurOuter1" stddeviation="10"></fegaussianblur> 
            <fecolormatrix in="shadowBlurOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0.2   0 0 0 0 0.2   0 0 0 0 0.2  0 0 0 0.5 0"> 
            </fecolormatrix> 
            <femerge> 
             <femergenode in="shadowMatrixOuter1"></femergenode> 
             <femergenode in="SourceGraphic"></femergenode> 
            </femerge> 
           </filter> 
           <rect id="ngrok-demo-b" width="600" height="320" rx="10"></rect> 
           <path id="ngrok-demo-c" d="M10,0 L590,0 L590,0 C595.522847,-1.01453063e-15 600,4.4771525 600,10 L600,32 L0,32 L0,10 L0,10 C-6.76353751e-16,4.4771525 4.4771525,1.01453063e-15 10,0 Z"> 
           </path> 
           <rect id="ngrok-demo-d" width="400" height="20" x="100" y="6" rx="4"></rect> 
           <filter id="ngrok-demo-e" width="108.3%" height="115.6%" x="-4.2%" y="-6.2%" filterunits="objectBoundingBox"> 
            <feoffset dy="5" in="SourceAlpha" result="shadowOffsetOuter1"></feoffset> 
            <fegaussianblur in="shadowOffsetOuter1" result="shadowBlurOuter1" stddeviation="10"></fegaussianblur> 
            <fecolormatrix in="shadowBlurOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0.2   0 0 0 0 0.2   0 0 0 0 0.2  0 0 0 0.5 0"> 
            </fecolormatrix> 
            <femerge> 
             <femergenode in="shadowMatrixOuter1"></femergenode> 
             <femergenode in="SourceGraphic"></femergenode> 
            </femerge> 
           </filter> 
           <rect id="ngrok-demo-f" width="600" height="320" rx="10"></rect> 
          </defs> <g fill="none" fill-rule="evenodd"> 
           <g class="browser" filter="url(#ngrok-demo-a)"> 
            <use fill="#FFF" xlink:href="#ngrok-demo-b"></use> 
            <rect width="599" height="319" x=".5" y=".5" stroke="#BBB" rx="10"></rect> 
            <use fill="#F5F5F5" xlink:href="#ngrok-demo-c"></use> 
            <path stroke="#BBB" d="M0.5,31.5 L599.5,31.5 L599.5,10 C599.5,4.75329488 595.246705,0.5 590,0.5 L10,0.5 C4.75329488,0.5 0.5,4.75329488 0.5,10 L0.5,31.5 Z"> 
            </path> 
            <use fill="#FFF" xlink:href="#ngrok-demo-d"></use> 
            <rect width="399" height="19" x="100.5" y="6.5" stroke="#BBB" rx="4"></rect> 
            <text fill="#222" font-family="Ubuntu" font-size="14"> 
             <tspan class="url" x="105" y="21">
              http://8to.top
             </tspan> 
            </text> 
            <path fill="#BBB" fill-rule="nonzero" d="M16,22.5 C12.4101491,22.5 9.5,19.5898509 9.5,16 C9.5,12.4101491 12.4101491,9.5 16,9.5 C19.5898509,9.5 22.5,12.4101491 22.5,16 C22.5,19.5898509 19.5898509,22.5 16,22.5 Z M16,21.5 C19.0375661,21.5 21.5,19.0375661 21.5,16 C21.5,12.9624339 19.0375661,10.5 16,10.5 C12.9624339,10.5 10.5,12.9624339 10.5,16 C10.5,19.0375661 12.9624339,21.5 16,21.5 Z M34,22.5 C30.4101491,22.5 27.5,19.5898509 27.5,16 C27.5,12.4101491 30.4101491,9.5 34,9.5 C37.5898509,9.5 40.5,12.4101491 40.5,16 C40.5,19.5898509 37.5898509,22.5 34,22.5 Z M34,21.5 C37.0375661,21.5 39.5,19.0375661 39.5,16 C39.5,12.9624339 37.0375661,10.5 34,10.5 C30.9624339,10.5 28.5,12.9624339 28.5,16 C28.5,19.0375661 30.9624339,21.5 34,21.5 Z M52,22.5 C48.4101491,22.5 45.5,19.5898509 45.5,16 C45.5,12.4101491 48.4101491,9.5 52,9.5 C55.5898509,9.5 58.5,12.4101491 58.5,16 C58.5,19.5898509 55.5898509,22.5 52,22.5 Z M52,21.5 C55.0375661,21.5 57.5,19.0375661 57.5,16 C57.5,12.9624339 55.0375661,10.5 52,10.5 C48.9624339,10.5 46.5,12.9624339 46.5,16 C46.5,19.0375661 48.9624339,21.5 52,21.5 Z"> 
            </path> 
            <g class="kates-site fade-in" fill="#BBB"> 
             <text font-family="Ubuntu-Bold, Ubuntu" font-size="21" font-weight="bold"> 
              <tspan x="0" y="20">
               一个值得信赖的验证程序
              </tspan> 
             </text> 
             <text font-family="Ubuntu" font-size="16"> 
              <tspan x="0" y="53">
               多功能API系统等你来体验
              </tspan> 
              <tspan x="0" y="73">
               欢迎来到简验证
              </tspan> 
             </text> 
            </g> 
           </g> 
           <g class="terminal" filter="url(#ngrok-demo-e)"> 
            <mask id="ngrok-demo-g" fill="#fff"> 
             <use xlink:href="#ngrok-demo-f"></use> 
            </mask> 
            <use fill="#222" xlink:href="#ngrok-demo-f"></use> 
            <rect width="600" height="320" fill="#222" mask="url(#ngrok-demo-g)" rx="10"></rect> 
            <g class="python-text slide-up" font-size="18" mask="url(#ngrok-demo-g)"> 
             <g transform="translate(16 8)"> 
              <text font-family="UbuntuMono-Bold, Ubuntu Mono" font-weight="bold"> 
               <tspan x="0" y="18" fill="#EBCE13">
                %
               </tspan> 
              </text> 
              <text font-family="UbuntuMono-Regular, Ubuntu Mono"> 
               <tspan class="command" x="20" y="18" fill="#BBB">
                简验证
               </tspan> 
               <tspan class="response show" x="20" y="40" fill="#BBB">
                用户已达到3000+
               </tspan> 
              </text> 
             </g> 
            </g> 
            <g class="ngrok-text show move-up" font-size="18" mask="url(#ngrok-demo-g)"> 
             <g transform="translate(16 74)"> 
              <text font-family="UbuntuMono-Bold, Ubuntu Mono" font-weight="bold"> 
               <tspan x="0" y="15" fill="#EBCE13">
                @
               </tspan> 
              </text> 
              <text font-family="UbuntuMono-Regular, Ubuntu Mono"> 
               <tspan class="command" x="20" y="15" fill="#FFF">
                简验证主要走向
               </tspan> 
              </text> 
              <text class="response show" font-family="UbuntuMono-Regular, Ubuntu Mono"> 
               <tspan x="20" y="37" fill="#7CE3F7">
                后台管理
               </tspan> 
               <tspan x="74" y="37" fill="#FFF">
               
               </tspan> 
               <tspan x="102" y="37" fill="#7CE3F7">
                源码下载
               </tspan> 
               <tspan x="20" y="81" fill="#EBCE13">
                简验证
               </tspan> 
               <tspan x="180" y="81" fill="#EBCE13">
                我的希望
               </tspan> 
               <tspan x="20" y="103" fill="#FFF">
                UI简洁
               </tspan> 
               <tspan x="180" y="103" fill="#FFF">
                我尽力完善UI给用户最好的体验
               </tspan> 
               <tspan x="20" y="125" fill="#FFF">
                API功能系统
               </tspan> 
               <tspan x="180" y="125" fill="#FFF">
                我尽力完善,后期会持续添加功能
               </tspan> 
               <tspan x="20" y="147" fill="#FFF">
                软件收费
               </tspan> 
               <tspan x="180" y="147" fill="#FFF">
                这是没办法的,毕竟都是做软件的嘛
               </tspan> 
               <tspan x="20" y="169" fill="#FFF">
                后台感想
               </tspan> 
               <tspan x="180" y="169" fill="#FFF">
                岁月不居,时节如流-期待居流以后更好的发展
               </tspan> 
              </text> 
             </g> 
            </g> 
           </g> 
          </g> 
         </svg> 
        </div> 
       </div> 
       <h1>简验证APP</h1> 
       <div class="info-desc">
        一个不错的验证程序
       </div> 
       <div class="btn-container"> <a class="btn btn-start btn-start--pc" href="<?php echo file_get_contents('admin/gxlj.txt') ; ?>">开始下载</a> <a class="btn btn-start btn-start--h5" href="<?php echo file_get_contents('admin/gxlj.txt') ; ?>">开始下载</a>
       </div> 
      </div> 
     </div> 
     <div class="feature-wrapper"> 
      <div class="main-title">
       为啥选择我们？
      </div> 
      <div class="panel-container"> 
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/1.png">
        </div> 
        <div class="panel-title">
         多功能API系统
        </div> 
        <div class="panel-desc">
         API接口拥有8大+功能系统<br>稳定,安全,高效操作系统!
        </div> 
       </div> 
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/2.png">
        </div> 
        <div class="panel-title">
         高速宽大
        </div> 
        <div class="panel-desc">
        高配服务器群组以及千兆带宽，只为提升更好的服务体验！
        </div> 
       </div> 
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/3.png">
        </div> 
        <div class="panel-title">
         操作简单
        </div> 
        <div class="panel-desc">
         UI简洁,功能强大,实用方便,小白也能对接!(内置API对接源码)
        </div> 
       </div> 
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/4.png">
        </div> 
        <div class="panel-title">
         软件功能
        </div> 
        <div class="panel-desc">
         我们提供iApp实例代码,优质源码下载服务,让你高效学习iapp!
        </div> 
       </div> 
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/5.png">
        </div> 
        <div class="panel-title">
         数据统计
        </div> 
        <div class="panel-desc">
         已为100+应用提供API管理系统,<br>优质源码已超过100+上传。
        </div> 
       </div>
       <div class="panel"> 
        <div class="panel-img">
         <img src="res/6.png">
        </div> 
        <div class="panel-title">
         作者总结
        </div> 
        <div class="panel-desc">
         闲假时间创建的居流,希望你能喜欢。<br>基于兴趣 趋于利益!
        </div> 
       </div> 
      </div> 
     </div> 
     <div style="height: 30px;"></div> 
     <div style="width=100%;padding: 5px;" align="center">

    <div style="text-align:center;font-size:12px;color:#adadad;margin:10px;margin-bottom: 35px;"><a href="about.html">Copyright © 2021  简验证</a>
    </div>
</script> 
 </body>
</html>