<?php

require 'config.php';

$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$title=$_REQUEST['title'];

if($zh==''||$mm==''||$title==''){die('参数不完整');}
if(!$link){die('数据库链接失败');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
$row=mysqli_fetch_assoc($sql);
if(!mysqli_num_rows($sql)>0){die('账号不存在');}
if($mm==$row['password']){}else{die('账号或密码错误');}
$sql=mysqli_query($link,"select * from api where title='$title'");
if(mysqli_num_rows($sql)>0){die('应用名已被占用');}

$row=mysqli_fetch_assoc(mysqli_query($link,"select * from user where user='$zh'"));
if($row['vip']=='true'){
    $sql=mysqli_query($link,"INSERT INTO api (user,title) VALUES ('$zh','$title')");
if($sql){die('创建成功');}else{die('失败error');}

}elseif(mysqli_num_rows(mysqli_query($link,"select * from api where user='$zh'"))>0){
    die('普通用户只能创建一个API:会员用户不限');
}else{
    $sql=mysqli_query($link,"INSERT INTO api (user,title) VALUES ('$zh','$title')");
if($sql){die('创建成功');}else{die('失败error');}

}
?>