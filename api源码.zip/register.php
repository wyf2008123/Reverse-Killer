<?php

require 'config.php';

//$ip=$_SERVER['REMOTE_ADDR'];
//$iplong=ip2long($ip);
$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];

if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''){die('参数不完整');}
if(!is_numeric($zh)==true){die('账号只能为阿拉伯数字');}
//if(!strlen($zh)>5||strlen($zh)<12){die('账号长度在6-11之间');}
//if(!strlen($mm)>6||strlen($mm)<12){die('密码长度在7-11之间');}
$sqlt=mysqli_query($link,"select * from user where user='$zh'");
if(mysqli_num_rows($sqlt)>0){die('账号已存在');}

//$sql=mysqli_query($link,"select * from user where ip='$iplong'");
//if(mysqli_num_rows($sql)>1){die('已达IP最高注册量');}


$sql=mysqli_query($link,"INSERT INTO user (user,password,vip,ban) values ('$zh','$mm','false','false')");
if($sql){die('注册成功');}else{die('注册失败');}
?>