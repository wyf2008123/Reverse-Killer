<?php

require '../config.php';

$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$app=$_REQUEST['appid'];
$did=$_REQUEST['did'];
$vip=$_REQUEST['vip'];
if(!$vip=='false'||!$vip=='true'){die('参数vip只能为布尔值');}

if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''||$app==''||$did==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
if(!mysqli_num_rows($sql)>0){die('账号不存在');}
$row=mysqli_fetch_assoc($sql);
if($mm==$row['password']){}else{die('账号或密码错误');}
$sql=mysqli_query($link,"select * from api where id='$app'");
if(!mysqli_num_rows($sql)>0){die('应用api不存在');}
$sql=mysqli_query($link,"select * from userid where did='$did'");
if(!mysqli_num_rows($sql)>0){die('id不存在');}
$sql=mysqli_query($link,"update userid set vip='$vip' where user='$zh' and appid='$app' and did='$did'");
if($sql){die('修改成功');}else{die('修改失败');}


?>