<?php

require '../config.php';

$user=$_REQUEST['user'];
$zt=$_REQUEST['zt'];
$ip=$_SERVER['REMOTE_ADDR'];

if(!mysqli_fetch_assoc(mysqli_query($link,"select * from admin where ip='$ip'"))['ip']==$ip){die('非法操作，已记录ip:'.$ip);}


if(!$link){die('数据库链接失败');}
if($user==''||$zt==''){die('参数不完整');}
if($zt==true||$zt==false){}else{die('参数值错误');}

$sql=mysqli_query($link,"select * from user where user='$user'");
if(!mysqli_num_rows($sql)>0){die('用户不存在');}

$sql=mysqli_query($link,"update user set ban='$zt' where user='$user'");
if($sql){die('修改成功');}else{die('修改失败');}


?>