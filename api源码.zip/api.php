<?php

$data=$_REQUEST['data'];
$zt=$_REQUEST['zt'];

if($data==''||$zt==''){die('参数不完整');}

if($zt=='aes_en'){
    $mm=$_REQUEST['mm'];
    echo openssl_encrypt($data,'AES-128-ECB',$mm,0);
}

if($zt=='aes_de'){
    $mm=$_REQUEST['mm'];
    echo openssl_decrypt($data,'AES-128-ECB',$mm,0);
}

if($zt=='md5'){
    echo md5($data);
}


?>