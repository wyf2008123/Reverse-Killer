-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: xr
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `ip` varchar(99) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'164.155.252.12');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api`
--

DROP TABLE IF EXISTS `api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `title` varchar(99) NOT NULL,
  `aeskey` varchar(99) NOT NULL DEFAULT 'baiqing',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api`
--

LOCK TABLES `api` WRITE;
/*!40000 ALTER TABLE `api` DISABLE KEYS */;
INSERT INTO `api` VALUES (10,'1915733303','软件库','baiqing'),(11,'1','123','baiqing'),(12,'123456','逆向杀手','yujiannbnixiangs'),(13,'49543378','49543378','baiqing'),(18,'3113395','1','baiqing'),(20,'3454865121','童年网络','baiqing'),(21,'3247695860','盧佈','baiqing'),(22,'2580','胆小鬼','baiqing'),(23,'487993838','笙歌','baiqing'),(28,'081203','小白','baiqing'),(36,'2383601182','白情','yujiansb66666666'),(37,'123456999','11','baiqing'),(40,'2383601182','666','yujiansb66666666'),(42,'147258369','123789','yujiansb66666666'),(44,'636117','555','llllllllllllllll'),(45,'20181818','jjj','baiqing'),(46,'1123','1123','baiqing'),(47,'100001','lieyan','qwertyuiopasdfgh'),(48,'1945144394','mmmmm','baiqing'),(49,'1337778','5366','baiqing'),(51,'123456789123','com.iba9334f36a375704','baiqing'),(52,'114514','天灯盒子','tiandeng11451419'),(53,'15223869664','ok','baiqing'),(54,'1251967467','66','baiqing'),(55,'2021468673','aikun','baiqing'),(56,'1142858116','ichat','baiqing'),(57,'3491439337','hfvjh','baiqing'),(58,'336699','轻简公益版','1234567891234567'),(59,'3325866074','༺空༒荧༻','baiqing');
/*!40000 ALTER TABLE `api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `user` bigint(50) NOT NULL,
  `password` varchar(99) NOT NULL,
  `vip` varchar(99) NOT NULL,
  `ban` varchar(99) NOT NULL DEFAULT 'false',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (30,2383601182,'123456','true','false'),(31,1,'1','false','400592674'),(32,162176178,'16465451','false','1864386330'),(33,1621761788,'16465451','false','1864386330'),(34,1621761788966,'16465451','false','null'),(35,16217617889,'16465451','false','null'),(36,123456,'wyf2008123','false','false'),(37,49543378,'495433','false','true'),(38,3113395,'3113395','false','null'),(39,20181818,'20181818','true','false'),(40,3454865121,'tongnian','false','null'),(41,12384802,'wxy20040707','false','null'),(42,3247695860,'3247695860','false','null'),(43,2580,'jyq07328','false','null'),(44,487993838,'123456789','false','null'),(45,81203,'081203','false','null'),(46,123456999,'123456789','false','null'),(47,147258369,'147258369','false','false'),(48,636117,'636117','false','false'),(49,1123,'hook2020','false','false'),(50,100001,'5201314','false','false'),(51,1945144394,'1945144394','false','false'),(52,123456789123,'123456789123','false','false'),(53,1337778,'1337778','false','false'),(54,114514,'1145141919','false','false'),(55,15223869664,'123456','false','false'),(56,1251967467,'123456','false','false'),(57,2021468673,'Zxcvbnm0808','false','false'),(58,3491439337,'ks1822532082','false','false'),(59,1142858116,'abc4584125','false','false'),(60,336699,'336699','false','false'),(61,3325866074,'1433223YG','false','false');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userid`
--

DROP TABLE IF EXISTS `userid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userid` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `user` varchar(99) NOT NULL,
  `appid` varchar(99) NOT NULL,
  `did` varchar(99) NOT NULL,
  `vip` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userid`
--

LOCK TABLES `userid` WRITE;
/*!40000 ALTER TABLE `userid` DISABLE KEYS */;
INSERT INTO `userid` VALUES (24,'2383601182','8','8877jjjuu','false'),(25,'2383601182','8','64646','false'),(26,'2383601182','8','123456','false'),(28,'2383601182','8','1234tjkt789','false'),(29,'2383601182','8','1234tkt789','false'),(30,'2383601182','8','124tkt789','false'),(31,'2383601182','8','124tkkt789','true'),(32,'2383601182','8','12tkkt789','false'),(33,'2383601182','19','nsjsj','false'),(34,'2383601182','19','ieiieieieieieiie','false'),(36,'2383601182','27','123456789','false'),(37,'2383601182','27','623db4f7a2c5b724','true'),(38,'2383601182','34','623db4f7a2c5b724','false'),(39,'2383601182','33','623db4f7a2c5b724','false'),(40,'2383601182','36','623db4f7a2c5b724','false'),(41,'2383601182','36','877034879095546','false'),(42,'2383601182','19','ieiieieieieieii','false'),(43,'2383601182','41','ieiieieieieieii','false'),(52,'147258369','42','623db4f7a2c5b724','true'),(92,'636117','44','e799061c76480192','true'),(97,'123456','12','5879b89339cc709f','true'),(98,'123456','12','c526e5b4c09f2ad3','false'),(99,'123456','12','af98a9a4d84bdddd','false'),(101,'123456','12','bf8cd5899e6862fa','false'),(102,'123456','12','c7333e559006aade','false'),(103,'123456','12','1d6d9d28e37ee461','false'),(104,'123456','12','1a032cf2d5e5c0a8','false'),(105,'123456','12','9a33a68ed137f68b','true'),(106,'123456','12','e0116f187520ce44','false'),(107,'123456','12','258edb461f7f15b3','false'),(108,'123456','12','60a50d2f11931ca7','false'),(109,'123456','12','309a44dac3d8b956','false'),(110,'123456','12','dc2a0ee72d2c4741','false'),(111,'123456','12','866917035334935','false'),(112,'123456','12','a09a180c9d60d724','false'),(113,'123456','12','5aa2662ddc6101dc','false'),(114,'123456','12','508e29d9f5b93c1b','false'),(115,'123456','12','863662038820331','false'),(116,'123456','12','e2d00b890225c805','false'),(117,'123456','12','57b0f5ca25968d21','false'),(118,'123456','12','24a5226eaef4253c','false'),(119,'123456','12','866173038078893','false'),(120,'123456','12','ca9f2e4666b901d3','false'),(121,'123456','12','855c67f1a75839c3','false'),(122,'123456','12','06aff6adc0c271c0','false'),(123,'123456','12','234813191335318','false'),(124,'123456','12','6341881e3b59f08b','false'),(125,'123456','12','65b6d9fdd58cb122','false'),(126,'123456','12','35794cfd67b34abd','false'),(127,'123456','12','c3df5554df670910','false'),(128,'123456','12','d741df24c41fd52a','false'),(129,'123456','12','7556471f87f611be','false'),(130,'123456','12','3028abf13c5db672','false'),(131,'123456','12','42729d87e447aacf','false'),(132,'123456','12','cbb0a297080148d3','false'),(133,'123456','12','544d01418187c266','false'),(134,'123456','12','502812dac7f181ef','false'),(135,'123456','12','382526f1daff035c','true'),(136,'114514','52','4e1601c3050e11aa','true'),(137,'114514','52','623db4f7a2c5b724','true'),(138,'2383601182','45','ieiieieieiei','false'),(141,'114514','52','866173038078893','true'),(143,'114514','52','848a565b07f619ca','true'),(145,'114514','52','76f91ca035937a19','true'),(146,'114514','52','f1f0d7cd22ec5046','true'),(147,'114514','52','2bdb71de6f789214','true'),(148,'123456','12','35909f4fb2d4bb42','false'),(149,'123456','12','a41823e1768294cd','false'),(150,'123456','12','1ba6eb08e947cd21','false'),(151,'114514','52','c17011904ebc651a','false'),(152,'123456','12','ca87909ae1ca8e5f','false'),(153,'123456','12','A00000960B49E8','false'),(154,'123456','12','6aefba68105e0317','false'),(155,'114514','52','b3abcf85e990834e','false'),(156,'114514','52','860144045245086','false'),(157,'123456','12','45da49b02a603f10','false'),(158,'123456','12','daf5099c77c28f47','false'),(159,'123456','12','cb1c70c5bc4f2a65','false'),(160,'123456','12','5253ec5f99db5443','false'),(161,'123456','12','a8875c1fd53a8038','false'),(162,'336699','58','7076be11477e41e7','true'),(163,'123456','12','6e4b5b75bac0564a','false'),(164,'123456','12','b40c0524eee60c80','false'),(165,'2383601182','40','95abb23c-7e3c-37c0-8ec4-18eefbdf51a2','false'),(167,'2383601182','40','33d06622-2836-3d23-a56d-a3a183e5f979','false');
/*!40000 ALTER TABLE `userid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wd`
--

DROP TABLE IF EXISTS `wd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wd` (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `title` varchar(99) NOT NULL,
  `content` varchar(9999) NOT NULL,
  `link` varchar(99) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wd`
--

LOCK TABLES `wd` WRITE;
/*!40000 ALTER TABLE `wd` DISABLE KEYS */;
INSERT INTO `wd` VALUES (1,'[增加id]','方法:GET/POST\r\n提交参数:\r\nuser=你的简验证账号\r\nappid=你创建的应用id\r\nid=用户id\r\n返回参数:\r\n增加成功|增加失败','提交网址:http://8to.top/api/id_add.php'),(2,'[删除id]','方法:GET/POST\r\n提交参数:\r\nuser=你的简验证账号\r\npassword=你的简验证密码\r\nappid=你创建的应用id\r\ndid=用户id\r\n返回参数:\r\n删除成功|删除失败','提交网址:http://8to.top/api/id_delete.php'),(3,'[给予id授权]','方法:GET/POST\r\n提交参数:\r\nuser=你的简验证账号\r\npassword=你的简验证密码\r\nappid=你创建的应用id\r\ndid=用户id\r\nvip=false||true\r\n返回参数:\r\n修改成功||修改失败','提交网址:http://8to.top/api/id_vip.php'),(4,'[查询id](客户端不建议使用该接口)','方法:GET/POST\r\n提交参数:\r\nuser=你的简验证账号\r\npassword=你的简验证密码\r\nappid=你创建的应用id\r\ndid=要查询的用户id\r\n返回参数:\r\n授权状态','提交网址:http://8to.top/api/id_sou.php'),(5,'[查询id]','方法GET/POST\r\n提交参数:\r\nuser=你的简验证账号\r\nappid=你创建的应用id\r\ndid=要查询的用户id\r\n返回参数:\r\nAES加密过的授权状态\r\nAES密匙信息可在简验证客户端配置','提交网址:http://8to.top/api/api_select_id_vip.php'),(10,'[查询id|动态md5+aes]','方法GET/POST\r\n提交参数:\r\nuser=你的简验证用户\r\nappid=你的应用api id\r\ndid=要查询的用户id\r\n返回参数\r\naes加密的授权状态\r\n对接示例:http://8to.top/com.简验证.iApp','提交网址:http://8to.top/api/id_aes_fh.php');
/*!40000 ALTER TABLE `wd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'xr'
--

--
-- Dumping routines for database 'xr'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 18:45:35
