<?php

require '../config.php';
$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$app=$_REQUEST['appid'];
if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''||$app==''){die('参数不完整');}
if(!is_numeric($zh)==true){die('账号只能为阿拉伯数字');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
if(!mysqli_num_rows($sql)>0){die('账号不存在');}
$row=mysqli_fetch_assoc($sql);
if($mm==$row['password']){}else{die('账号或密码错误');}
$sql=mysqli_query($link,"select * from userid where user='$zh' and appid='$app' order by id desc");
$row_sl=mysqli_num_rows($sql);
if(!mysqli_num_rows(mysqli_query($link,"select * from api where id='$app'"))>0){die('应用api不存在');}
for ($i = 0; $i < $row_sl; $i++) {
    $row=mysqli_fetch_assoc($sql);
    echo '[id]'.$row['did'].'[id]'.'[vip]'.$row['vip'].'[vip]'.'<br>';
}

?>