<?php

require 'config.php';

$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];

if($zh==''||$mm==''){die('参数不完整');}
if(!$link){die('数据库链接失败');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
if(!mysqli_num_rows($sql)>0){die('账号不存在');}
$row=mysqli_fetch_assoc($sql);
if($row['ban']=='true'){die('账号已被封禁');}
if($mm==$row['password']){}else{die('账号或密码错误');}

$sql=mysqli_query($link,"select * from api where user='$zh' order by id desc");
$row_sl=mysqli_num_rows($sql);
for ($i = 0; $i < $row_sl; $i++) {
    $row=mysqli_fetch_assoc($sql);
    echo '[id]'.$row['id'].'[id]'.'[title]'.$row['title'].'[title]'.'<br>';
}


?>