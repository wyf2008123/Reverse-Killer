<?php

require '../config.php';
$zh=$_REQUEST['user'];
$mm=$_REQUEST['password'];
$app=$_REQUEST['appid'];
$did=$_REQUEST['did'];

if(!$link){die('数据库链接失败');}
if($zh==''||$mm==''||$app==''||$did==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from user where user='$zh' and password='$mm'");
if(!mysqli_num_rows($sql)>0){die('账号或密码错误');}
$sql=mysqli_query($link,"select * from api where user='$zh' and id='$app'");
if(!mysqli_num_rows($sql)>0){die('应用api不存在');}
$sql=mysqli_query($link,"select * from userid where appid='$app' and did='$did' and user='$zh'");
if(!mysqli_num_rows($sql)>0){die('用户id不存在');}
$sql=mysqli_query($link,"delete from userid where user='$zh' and appid='$app' and did='$did'");
if($sql){die('删除成功');}else{die('删除失败');}

?>