<?php
$conn=array(
    'sqlname'=>'xr',
    'sqluser'=>'xr',
    'sqlpass'=>'xr'
    );
$link=mysqli_connect('localhost',$conn['sqluser'],$conn['sqlpass'],$conn['sqlname']);
?>