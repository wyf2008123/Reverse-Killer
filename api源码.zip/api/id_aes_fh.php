<?php

require '../config.php';

$zh=$_REQUEST['user'];
$appid=$_REQUEST['appid'];
$did=$_REQUEST['did'];

if(!$link){die('数据库链接失败');}
if($zh==''||$appid==''||$did==''){echo json_encode(array('did'=>200,'vip'=>'参数不完整'));}

$sqli=mysqli_query($link,"select * from api where id='$appid' and user='$zh'");
if(!mysqli_num_rows($sqli)>0){die('账号或api不存在');}

$sql=mysqli_query($link,"select * from userid where user='$zh' and appid='$appid'");
if(!mysqli_num_rows($sql)>0){echo json_encode(array('did'=>500,'vip'=>'用户id不存在'));
    die();
}

$aeskey=mysqli_fetch_assoc($sqli)['aeskey'];

$yjm=json_encode(array('did'=>$did,'vip'=>mysqli_fetch_assoc(mysqli_query($link,"select * from userid where user='$zh' and appid='$appid' and did='$did'"))['vip']));

if($aeskey=='baiqing'){echo json_encode(array('did'=>500,'vip'=>'简验证用户未配置AES密匙'));
    die();
}

$ms=substr(md5($aeskey.date('Y-m-d H:i')),0,16);

echo openssl_encrypt($yjm,'AES-128-ECB',$ms,0);

?>