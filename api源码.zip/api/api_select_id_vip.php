<?php

require '../config.php';

$zh=$_REQUEST['user'];
$appid=$_REQUEST['appid'];
$did=$_REQUEST['did'];

if(!$link){die('数据库链接失败');}
if($zh==''||$appid==''||$did==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from api where user='$zh' and id='$appid'");
if(!mysqli_num_rows($sql)>0){die('应用api不存在');}
$api=mysqli_fetch_assoc($sql);

$sql=mysqli_query($link,"select * from userid where appid='$appid' and did='$did'");
if(!mysqli_num_rows($sql)>0){die('id不存在');}
$row=mysqli_fetch_assoc($sql);
$aes=$api['aeskey'];
if($aes=='baiqing'){die('简验证用户未配置AES密匙');}
$array=array('did'=>$row['did'],'vip'=>$row['vip']);
$ysc=json_encode($array);
$jm=openssl_encrypt($ysc,'AES-128-ECB',$aes,0);
echo $jm;

?>