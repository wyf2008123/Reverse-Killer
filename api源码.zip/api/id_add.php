<?php

$zh=$_REQUEST['user'];
$app=$_REQUEST['appid'];
$id=$_REQUEST['id'];
$vip='false';

require '../config.php';
if(!$link){die('数据库链接失败');}
if($zh==''||$id==''||$app==''){die('参数不完整');}

$sql=mysqli_query($link,"select * from user where user='$zh'");
if(mysqli_num_rows($sql)>0){}else{die('账号不存在');}
$sql=mysqli_query($link,"select * from api where id='$app'");
if(!mysqli_num_rows($sql)>0){die('应用api不存在');}
$sql=mysqli_query($link,"select * from userid where did='$id' and user='$zh' and appid='$app'");
if(!mysqli_num_rows($sql)>0){
    $sql=mysqli_query($link,"INSERT INTO userid (did,user,vip,appid) VALUES ('$id','$zh','$vip','$app')");
    if($sql){die('插入成功');}else{die('插入失败');}
}else{die('id已存在');}

?>