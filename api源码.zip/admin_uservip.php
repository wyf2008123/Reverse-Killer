<?php

require 'config.php';
$user=$_REQUEST['user'];
$vip='true';

if(!$link){die('数据库链接失败');}
if($user==''){die('参数不完整');}

$sql=mysqli_query($link,"update user set vip='$vip' where user='$user'");
if($sql){die('修改成功');}


?>